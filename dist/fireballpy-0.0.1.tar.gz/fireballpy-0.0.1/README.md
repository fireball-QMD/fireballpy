[![lite-badge](https://jupyterlite.rtfd.io/en/latest/_static/badge.svg)](https://fireball-QMD.github.io/fireballpy/lab)
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/fireball-QMD/pyreball/HEAD?labpath=examples/fireballpy_skeleton.ipynb)

git clone https://github.com/fireball-QMD/fireballpy


Quitar V_intra_dip  AQUI
 ! AQUI QUITAR idynmat iephc ?
  !AQUI  ewaldqmmm dejar preguntar a Jesus
quedarse con la mejor autoconsistencia Kscf AQUI 
