.. module:: fireballpy

.. _reference:

########################
FireballPy API reference
########################

**Release:** |release|
**Date:** |today|

Fireball
^^^^^^^^

.. autosummary::
   :toctree: generated/

   Fireball


InfoDat
^^^^^^^

.. autosummary::
   :toctree: generated/

   InfoDat
