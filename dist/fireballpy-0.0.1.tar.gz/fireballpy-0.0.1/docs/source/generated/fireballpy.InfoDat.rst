﻿fireballpy.InfoDat
==================

.. currentmodule:: fireballpy

.. autoclass:: InfoDat

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~InfoDat.__init__
      ~InfoDat.load
      ~InfoDat.save
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~InfoDat.shells
      ~InfoDat.shellsPP
      ~InfoDat.cutoffPP
      ~InfoDat.cutoffs
      ~InfoDat.qneutral
      ~InfoDat.wffiles
      ~InfoDat.nafiles
      ~InfoDat.energy
      ~InfoDat.numbers
      ~InfoDat.numshells
      ~InfoDat.numshellsPP
      ~InfoDat.elements
   
   