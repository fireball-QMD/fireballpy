.. module:: fireballpy

.. _reference:

##########################
FireballPy Getting started
##########################

**Release:** |release|
**Date:** |today|

TODO
